#!/bin/bash
echo "Installing AI Consensus dependencies..."
pip install numpy pandas scikit-learn
echo "AI Consensus dependencies installed."
