#!/bin/bash
echo "🔧 Installing AI Consensus Layer..."
mkdir -p /usr/local/pkrd/ai_consensus
cp ai_consensus.py /usr/local/pkrd/ai_consensus/
echo "✅ AI Consensus Module installed at /usr/local/pkrd/ai_consensus"
