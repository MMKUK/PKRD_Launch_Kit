#!/bin/bash
echo "🛠️ Installing Living Chain Protocol..."
mkdir -p /usr/local/pkrd/living_chain
cp living_chain.py /usr/local/pkrd/living_chain/
echo "✅ Living Chain Protocol installed at /usr/local/pkrd/living_chain"
